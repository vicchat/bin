/*
	Anti-HUDHide is an addon that prevents the HUD (heads-up-display) from disapearing when you open menus.

	Anti-HUDHide is compadible with web libraries too - just click on Anti-HUDHide in the downloads section and once you're into the world type "import" into the chat.

	The information above should be displayed at the page you download this addon from (Above for reminder). Thank you for downloading Anti-HUDHide and have a good day!!!
*/
enterMode = true;

var toimport = false;
var toaddon = false;

mendTog = function(trueorfalse) {
	console.log("Anti-HUDHide: Not today!");
}

window.setInterval(function() {
	if (toimport === false) {
		if (lastMessage === "import") {
			lastMessage = null;
			varf(libimport);
			clearChat();
			chatMessage.style.display = "none";
			toimport = true;
		}
	}
}, 10);