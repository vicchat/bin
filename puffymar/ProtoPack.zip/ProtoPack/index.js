/*
	Thank you for installing ProtoPack, the #1 Modifier and Addon for giving The Random Puffy Thingy and the Big Scary Void a prototype look and feel.

	Why are you reading this if you could be using it?
*/

enterMode = true;

area.style.backgroundImage = "url(https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/background-of-green-and-healthy-grass-royalty-free-image-1586800097.jpg?crop=0.68819xw:1xh;center,top&resize=400:*)";
area.style.outline = "ridge 50px brown";

var appendTree = function(x, y) {
	var newtree = document.createElement("img");
		newtree.setAttribute("src", "http://www.clker.com/cliparts/Z/Q/1/5/y/e/green-tree-md.png");
		newtree.setAttribute("width", "150");
		newtree.style.position = "absolute";
		newtree.style.left = x + "px";
		newtree.style.top = y + "px";
	area.appendChild(newtree);
}

var appendTornado = function() {
	var nwetor = document.createElement("img");
		nwetor.setAttribute("src", "http://www.clker.com/cliparts/7/8/3/m/P/v/tornado-md.png");
		nwetor.setAttribute("width", "150");
		nwetor.style.position = "absolute";
		nwetor.style.left = "500px";
		nwetor.style.top = "1200px";
	area.appendChild(nwetor);
}

var appendVolcano = function() {
	var nwevol = document.createElement("img");
		nwevol.setAttribute("src", "https://www.jing.fm/clipimg/full/33-339689_volcano-freetoedit-cartoon-volcanic-eruption-gif.png");
		nwevol.setAttribute("width", "150");
		nwevol.style.position = "absolute";
		nwevol.style.left = "950px";
		nwevol.style.top = "300px";
	area.appendChild(nwevol);
}

appendTree(170, 95);
appendTree(1100, 750);
appendTree(650, 300);
appendTree(200, 1450);
appendTree(350, 450);
appendTree(850, 1200);
appendTree(1450, 150);
appendTree(400, 950);
appendTree(750, 650);
appendTree(1325, 1545);
appendTree(2300, 2300);
appendTree(2300, 100);
appendTree(100, 2300);
appendTree(1000, 2400);
appendTree(2400, 1650);
appendTree(1234, 1234);
appendTree(3000, 3000);
appendTree(100, 2800);
appendTree(2510, 650);
appendTree(1970, 980);
appendTree(1940, 440);
appendTree(770, 1820);

appendTornado();
appendVolcano();

window.setInterval(function() {
	if (playerX > 470 && playerX < 650 && playerY > 1160 && playerY < 1410) {
		you_died(`${$.name} went inside the storm.`);
	} else if (playerX > 900 && playerX < 1100 && playerY > 250 && playerY < 430) {
		you_died(`${$.name} went to the volcano.`);
	}
}, 10);