Thank you for installing ProtoPack!
Folow theese instructions for where to put the folders:
 • Put the "ProtoPack" folder in the "Addons" directory
 • Put the "ProtoPack UI" folder in the "Menupacks" directory