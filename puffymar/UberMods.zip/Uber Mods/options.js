// Welcome to the UberMods options file, here you can enable and disable mods. See the download page (vicchat.github.io/ubermods) for more information.

var uberconfig = {
	mods: ["Useless Button"],
	all_mods: ["Useless Button"]
}