// Welcome to the UberMods options file, here you can enable and disable mods. See the download page (vicchat.github.io/ubermods) for more information.

var uberconfig = {
	mods: [],
	all_mods: []
}