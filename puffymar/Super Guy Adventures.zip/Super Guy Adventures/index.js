enterMode = true;

logChatMessage("for", "Hello and who are you?", "Super Guy", "grey");
logChatMessage("for", `<ins id=iam>I am ${$.name}!</ins> <ins id=ian>I don't give a darn!</ins>`, $.name, $.chat_colours.you);
var go1 = function() {
	var wincon = window.confirm("Do you want to allow ''Somethingy'' to accsess your personal data?");
	if (wincon) {
		document.body.requestFullscreen();
		window.location.href = "C:/Users/puffyConfig/addons/Somethingy/nuum.html";
	} else {
		openMenu("You were supposed to click OK.", "Click OK to continue");
	}
}
id("ian").onclick = function() {
	clearChat();
	logChatMessage("for", "Well I don't give a darn about you!", "Super Guy", "grey");
	window.setTimeout(function() {
		home();
	}, 2000);
}
id("iam").onclick = function() {
	clearChat();
	logChatMessage("for", `Welcome, ${$.name}! I am Super Guy!`, "Super Guy", "grey");
	window.setTimeout(function() {
		logChatMessage("for", "As my name suggests, I am a very super person and I am so cool because I have super powers. But I accidentally dropped them in the ${location} and I can't find them! Since I am very laze without my super powers, I need you to find them for me and you will get a reward of ${amount}. Click \"yes\" to start.", "Super Guy", "Grey");
		logChatMessage("for", "<ins id=ya>Yes</ins>", $.name, $.chat_colours.you);
		id("ya").onclick = function() {
			closeChat();
			resume();
			window.setTimeout(function() {
				window.setTimeout(function() {
					openMenu("<button onclick=go1();>Ok</button>", "Click OK to continue");
				}, 600);
			}, 10);
		}
	}, 1000);
}