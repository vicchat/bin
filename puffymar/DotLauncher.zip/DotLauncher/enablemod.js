if (window.location.href.includes("onload.html") === true) {
	document.getElementById("extractit").onclick = function() {
		var mte = document.getElementById("actiondiv-input").value;
		window.localStorage.setItem("mod", mte);
		window.location.href = "loading.html";
	}
} else if (window.location.href.includes("index.html") === true) {
	var enableMod = function() {
		var lib_ry = document.createElement("script");
			lib_ry.setAttribute("src", "mods/" + window.localStorage.getItem("mod") + "/scripts/index.js");
		document.body.appendChild(lib_ry);
		window.setTimeout(function() {
			if (enterMode === true) {
				document.getElementById("dotLauncher").style.display = "none";
				enabledMod = window.localStorage.getItem("mod");
				enterMode = false;
			} else {
				document.getElementById("dotLauncher").style.display = "block";
			}
		}, 1000);
	}
	enableMod();
}