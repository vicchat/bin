window.setTimeout(function() {
	window.location.href = "index.html";
}, 1950);